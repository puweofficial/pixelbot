PixelBot v3.0.0 (Auto-Placing Bot)
=====================================
Installation:
1. Install Tampermonkey or Violentmonkey in your browser.
2. Add initer.user.js as a new userscript.
3. initer.user.js will automatically load pixels.user-bot.js.
